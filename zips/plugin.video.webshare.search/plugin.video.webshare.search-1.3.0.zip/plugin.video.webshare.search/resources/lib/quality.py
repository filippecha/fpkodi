# -*- coding: utf-8 -*-
"""Odhad kvality videa z názvu souboru: rozlišení, jazyk, HDR, kodek."""
import re

_RESOLUTIONS = (
    (2160, r'2160p?|4k|uhd'),
    (1440, r'1440p?'),
    (1080, r'1080[pi]?|fullhd|fhd'),
    (720, r'720p?'),
    (480, r'480p?|576p?|dvdrip|dvd'),
)


def _has(text, pattern):
    """Hledá pattern jako samostatné slovo (oddělovače už jsou převedené na mezery)."""
    return re.search(r'(?<![a-z0-9])(?:%s)(?![a-z0-9])' % pattern, text) is not None


def parse(name):
    """Vrátí {'height': 1080, 'tags': ['1080p', 'CZ dabing', 'HEVC']}; height 0 = neznámé."""
    text = re.sub(r'[\s._\-\[\](){},+&]+', ' ', name.lower())

    height = 0
    for h, pattern in _RESOLUTIONS:
        if _has(text, pattern):
            height = h
            break

    tags = []
    if height:
        tags.append('4K' if height == 2160 else 'SD' if height == 480 else '%dp' % height)

    cz = _has(text, r'cz|cze|cs|cesky|česky|czech|cestina|čeština')
    sk = _has(text, r'sk|svk|slovak|slovensky')
    if _has(text, r'(?:cz|sk|cs)?dab\w*'):
        tags.append('SK dabing' if sk and not cz else 'CZ dabing')
    elif _has(text, r'(?:cz)?tit\w*|sub\w*'):
        tags.append('CZ titulky' if cz else 'titulky')
    elif cz:
        tags.append('CZ')

    if _has(text, r'3d'):
        tags.append('3D')
    if _has(text, r'hdr\w*|dv|dovi|dolby vision'):
        tags.append('HDR')
    if _has(text, r'x265|h 265|h265|hevc'):
        tags.append('HEVC')
    elif _has(text, r'av1'):
        tags.append('AV1')
    if _has(text, r'remux'):
        tags.append('REMUX')
    return {'height': height, 'tags': tags}


# Technické údaje, u kterých končí název filmu (porovnávají se celá slova)
_TECH = (r'\d{3,4}[pi]|4k|uhd|fullhd|fhd|hd|sd|hdr\w*|dv|sdr|x26[45]|h ?26[45]|hevc|avc|av1|xvid|divx|'
         r'blu ?ray|bluray|bd|bdrip|brrip|dvd|dvdrip|dvd5|dvd9|web|web ?dl|web ?rip|hdtv|tvrip|hdrip|camrip|cam|ts|remux|remastered|'
         r'proper|repack|extended|unrated|3d|'
         r'cz|cze|czech|cs|sk|svk|en|eng|ger|rus|multi|dab|dabing|dabovane|dabované|czdab|tit|titulky|cztit|sub|subs|subtitles|'
         r'aac|ac3|dts\w*|dd\d?|ddp\d?|atmos|truehd|\d ?ch|mp3|10 ?bit|8 ?bit|sample|trailer|'
         r's\d{1,2} ?e\d{1,3}|\d{1,2}x\d{2,3}')


def title_year(name):
    """Odhadne název filmu a rok z názvu souboru: 'Matrix.1999.1080p.CZ.mkv' -> ('Matrix', 1999).

    Rok je None, pokud v názvu není. Název může být prázdný, když soubor nemá rozpoznatelné jméno.
    """
    text = re.sub(r'\.[a-z0-9]{2,4}$', '', name, flags=re.I)
    text = re.sub(r'[._]+', ' ', text)
    text = re.sub(r'(?<=\w)-+(?=\w)', ' ', text)  # James-Bond-23-Skyfall
    text = re.sub(r'\s+', ' ', text).strip()

    year = None
    cut = len(text)
    # Rok = první samostatné 19xx/20xx, které není na začátku (např. '2001 Vesmírná odysea')
    for m in re.finditer(r'(?<![0-9a-z])(19\d{2}|20\d{2})(?![0-9a-z])', text, flags=re.I):
        if text[:m.start()].strip(' -([{,'):
            year, cut = int(m.group(1)), m.start()
            break
    m = re.search(r'(?<![0-9a-z])(?:%s)(?![0-9a-z])' % _TECH, text[:cut], flags=re.I)
    if m and text[:m.start()].strip(' -([{,'):
        cut = m.start()

    title = text[:cut]
    title = re.sub(r'[\(\[{][^\)\]}]*$', '', title)   # neuzavřená závorka před rokem: 'Matrix (The Matrix, '
    title = re.sub(r'[\(\[{][^\)\]}]*[\)\]}]', ' ', title)  # obsah závorek
    title = re.sub(r'\s+', ' ', title).strip(' -,([{')
    return title, year


def group_key(title, year):
    """Klíč pro seskupení bez TMDB: malá písmena, bez diakritiky a interpunkce."""
    import unicodedata
    t = unicodedata.normalize('NFKD', title.lower())
    t = ''.join(c for c in t if not unicodedata.combining(c))
    t = re.sub(r'[^a-z0-9]+', ' ', t).strip()
    return '%s|%s' % (t, year or '')


_EPISODE = re.compile(r'(?<![0-9a-z])(?:s(\d{1,2}) ?e(\d{1,3})|(\d{1,2})x(\d{2,3}))(?![0-9])', re.I)


def episode_code(name):
    """Číslo dílu z názvu souboru: 'Pratele.S01E05.avi' / 'Přátelé 1x05' -> (1, 5); jinak None."""
    m = _EPISODE.search(re.sub(r'[._]+', ' ', name))
    if not m:
        return None
    season, episode = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
    return int(season), int(episode)


def normalize(text):
    """Malá písmena bez diakritiky a interpunkce, pro porovnávání názvů."""
    import unicodedata
    t = unicodedata.normalize('NFKD', text.lower())
    t = ''.join(c for c in t if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9]+', ' ', t).strip()
