# -*- coding: utf-8 -*-
"""Vyhledání filmů na TMDB (https://developer.themoviedb.org/) s mezipamětí v souboru."""
import json
import os
import re
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from difflib import SequenceMatcher
from http.client import HTTPException
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

API_URL = 'https://api.themoviedb.org/3/'
IMG_URL = 'https://image.tmdb.org/t/p/'
TIMEOUT = 10
WORKERS = 8
NEGATIVE_TTL = 7 * 24 * 3600  # nenalezené názvy se po týdnu zkusí znovu
MAX_CACHE = 5000
MIN_SIMILARITY = 0.7  # podobnost názvu souboru a názvu filmu (0–1)
EXACT_SIMILARITY = 0.95  # od této podobnosti se další varianty názvu už nezkoušejí


class TmdbError(Exception):
    """Chyba, kvůli které nemá smysl zkoušet další dotazy (neplatný klíč)."""


def _norm(text):
    text = unicodedata.normalize('NFKD', text.lower())
    text = ''.join(c for c in text if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9]+', ' ', text).strip()


class Tmdb:
    def __init__(self, key, cache_file, language='cs-CZ'):
        self.key = key.strip()
        self.cache_file = cache_file
        self.language = language
        self.cache = self._load()

    # --- mezipaměť --------------------------------------------------------

    def _load(self):
        try:
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except (IOError, OSError, ValueError):
            return {}

    def _save(self):
        if len(self.cache) > MAX_CACHE:
            oldest = sorted(self.cache, key=lambda k: self.cache[k].get('t', 0))
            for k in oldest[:len(self.cache) - MAX_CACHE]:
                del self.cache[k]
        tmp = self.cache_file + '.tmp'
        try:
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(self.cache, f, ensure_ascii=False)
            os.replace(tmp, self.cache_file)
        except (IOError, OSError):
            pass

    @staticmethod
    def _key(title, year):
        return '%s|%s' % (_norm(title), year or '')

    # --- API --------------------------------------------------------------

    def _get(self, endpoint, params):
        params = dict(params)
        headers = {'Accept': 'application/json'}
        if self.key.startswith('eyJ'):  # API Read Access Token (v4)
            headers['Authorization'] = 'Bearer ' + self.key
        else:  # API Key (v3)
            params['api_key'] = self.key
        req = Request(API_URL + endpoint + '?' + urlencode(params), headers=headers)
        try:
            with urlopen(req, timeout=TIMEOUT) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except HTTPError as e:
            if e.code == 401:
                raise TmdbError('Neplatný TMDB API klíč. Zkontrolujte ho v nastavení doplňku.')
            raise

    def _search(self, title, year):
        params = {'query': title, 'language': self.language, 'include_adult': 'false'}
        if year:
            params['year'] = year
        results = self._get('search/movie', params).get('results') or []
        wanted = _norm(title)
        best, best_score = None, 0
        for r in results[:8]:
            date = r.get('release_date') or ''
            # 'year' v TMDB odpovídá i pozdějšímu uvedení (např. reedice), proto vlastní kontrola
            if year and not (date[:4].isdigit() and abs(int(date[:4]) - year) <= 1):
                continue
            # Nelatinské názvy (např. hindské) se normalizují skoro na nic, proto se prázdné vynechají
            names = [n for n in (_norm(r.get('title') or ''), _norm(r.get('original_title') or '')) if re.search('[a-z]', n)]
            if not names:
                continue
            if year:
                score = max(SequenceMatcher(None, wanted, n).ratio() for n in names)
            else:
                # Bez roku jen přesná shoda názvu, jinak by se přiřazovaly náhodné filmy
                score = 1.0 if wanted in names else 0
            if score > best_score:
                best, best_score = r, score
        return best, best_score

    def _lookup(self, title, year):
        candidates = [title]
        if year:
            # 'Matrix - The Matrix (1999)' => zkusí i český a anglický název zvlášť
            if ' - ' in title:
                candidates += [p.strip() for p in title.split(' - ') if p.strip()]
            # 'James Bond 007 Dnes neumírej 2002' => bez předpony série (rok a podobnost hlídají shodu)
            words = title.replace(' - ', ' ').split()
            candidates += [' '.join(words[i:]) for i in range(1, min(4, len(words)))]
        # Vyhrává nejpodobnější shoda ze všech variant ('Matrix - The Matrix' je podobné i 'Making The Matrix')
        best, best_score = None, 0
        for candidate in dict.fromkeys(candidates):
            if len(re.sub(r'[^a-z]', '', _norm(candidate))) < 4:
                continue  # '1', '007'… by se shodovaly s čímkoli
            r, score = self._search(candidate, year)
            if score > best_score:
                best, best_score = r, score
            if best_score >= EXACT_SIMILARITY:
                break
        return self._movie(best) if best_score >= MIN_SIMILARITY else None

    @staticmethod
    def _movie(r):
        date = r.get('release_date') or ''
        return {
            'id': r['id'],
            'title': r.get('title') or r.get('original_title') or '',
            'original_title': r.get('original_title') or '',
            'year': int(date[:4]) if date[:4].isdigit() else 0,
            'plot': r.get('overview') or '',
            'rating': float(r.get('vote_average') or 0),
            'votes': int(r.get('vote_count') or 0),
            'poster': IMG_URL + 'w500' + r['poster_path'] if r.get('poster_path') else '',
            'fanart': IMG_URL + 'w1280' + r['backdrop_path'] if r.get('backdrop_path') else '',
        }

    def lookup_many(self, pairs):
        """Pro seznam (název, rok) vrátí {(název, rok): film nebo None}. Chybějící dohledá souběžně."""
        now = time.time()
        result, todo = {}, []
        for pair in set(pairs):
            hit = self.cache.get(self._key(*pair))
            if hit and (hit.get('m') or now - hit.get('t', 0) < NEGATIVE_TTL):
                result[pair] = hit.get('m')
            else:
                todo.append(pair)
        if not todo:
            return result
        with ThreadPoolExecutor(WORKERS) as pool:
            futures = {pair: pool.submit(self._lookup, *pair) for pair in todo}
        try:
            for pair, future in futures.items():
                try:
                    movie = future.result()
                except (OSError, HTTPException, ValueError, KeyError):
                    continue  # výpadek sítě: necacheovat, zkusí se příště
                self.cache[self._key(*pair)] = {'t': now, 'm': movie}
                result[pair] = movie
        finally:
            self._save()
        return result

    # --- procházení a seriály ---------------------------------------------
    # Tyto metody vyhazují i síťové chyby (OSError, HTTPException, ValueError), ošetřuje je volající.

    MOVIE_LISTS = {
        'trending': ('trending/movie/day', {}),
        'popular': ('movie/popular', {'region': 'CZ'}),
        'now_playing': ('movie/now_playing', {'region': 'CZ'}),
        # movie/top_rated obsahuje i filmy s pár hlasy, proto discover s minimem hodnocení
        'top_rated': ('discover/movie', {'sort_by': 'vote_average.desc', 'vote_count.gte': 2000}),
    }
    # Bez talk show, zpráv, reality show a telenovel; ty na Webshare skoro nejsou
    TV_SKIP_GENRES = {10763, 10764, 10766, 10767}
    TV_LISTS = {
        'trending': ('trending/tv/day', {}),
        'popular': ('discover/tv', {'sort_by': 'popularity.desc', 'vote_count.gte': 100,
                                    'without_genres': '10763|10764|10766|10767'}),
        'on_the_air': ('tv/on_the_air', {}),
        'top_rated': ('discover/tv', {'sort_by': 'vote_average.desc', 'vote_count.gte': 1000,
                                      'without_genres': '10763|10764|10766|10767'}),
    }

    def movie_list(self, kind, page=1):
        """Vrátí ([filmy], počet stran). kind: trending, popular, now_playing, top_rated, digital."""
        if kind == 'digital':
            # Nově na VOD a Blu-ray: digitální (4) nebo fyzické (5) vydání za posledních 30 dní
            today = time.strftime('%Y-%m-%d')
            month_ago = time.strftime('%Y-%m-%d', time.localtime(time.time() - 30 * 24 * 3600))
            endpoint, params = 'discover/movie', {
                'with_release_type': '4|5', 'release_date.gte': month_ago, 'release_date.lte': today,
                'sort_by': 'popularity.desc', 'vote_count.gte': 20}
        else:
            endpoint, params = self.MOVIE_LISTS[kind]
        data = self._get(endpoint, dict(params, language=self.language, page=page))
        return [self._movie(r) for r in data.get('results') or []], min(int(data.get('total_pages') or 1), 500)

    def tv_list(self, kind, page=1):
        endpoint, params = self.TV_LISTS[kind]
        data = self._get(endpoint, dict(params, language=self.language, page=page))
        shows = [self._tv(r) for r in data.get('results') or []
                 if not self.TV_SKIP_GENRES & set(r.get('genre_ids') or []) and int(r.get('vote_count') or 0) >= 10]
        # Bez českého ani latinského názvu (čínské, korejské…) by se na Webshare stejně nenašlo
        shows = [sh for sh in shows if re.search('[A-Za-z]', sh['title'])]
        return shows, min(int(data.get('total_pages') or 1), 500)

    def movie(self, movie_id):
        m = self._movie(self._get('movie/%d' % movie_id, {'language': self.language}))
        # Anglický název: české filmy bývají na Webshare často jen pod ním (Pelíšky = Cosy Dens)
        m['english_title'] = self._get('movie/%d' % movie_id, {'language': 'en-US'}).get('title') or ''
        return m

    def search_tv(self, query):
        data = self._get('search/tv', {'query': query, 'language': self.language, 'include_adult': 'false'})
        return [self._tv(r) for r in data.get('results') or []]

    def tv(self, tv_id):
        """Seriál včetně seznamu sezón."""
        r = self._get('tv/%d' % tv_id, {'language': self.language})
        show = self._tv(r)
        show['english_title'] = self._get('tv/%d' % tv_id, {'language': 'en-US'}).get('name') or ''
        show['seasons'] = [{
            'number': s['season_number'],
            'name': s.get('name') or 'Série %d' % s['season_number'],
            'episodes': int(s.get('episode_count') or 0),
            'year': int((s.get('air_date') or '')[:4]) if (s.get('air_date') or '')[:4].isdigit() else 0,
            'plot': s.get('overview') or '',
            'poster': IMG_URL + 'w500' + s['poster_path'] if s.get('poster_path') else show['poster'],
        } for s in r.get('seasons') or [] if s.get('season_number') is not None]
        return show

    def season(self, tv_id, number):
        r = self._get('tv/%d/season/%d' % (tv_id, number), {'language': self.language})
        return [{
            'season': e.get('season_number', number),
            'episode': e['episode_number'],
            'name': e.get('name') or '',
            'plot': e.get('overview') or '',
            'aired': e.get('air_date') or '',
            'rating': float(e.get('vote_average') or 0),
            'votes': int(e.get('vote_count') or 0),
            'still': IMG_URL + 'w780' + e['still_path'] if e.get('still_path') else '',
        } for e in r.get('episodes') or []]

    @staticmethod
    def _tv(r):
        date = r.get('first_air_date') or ''
        return {
            'id': r['id'],
            'title': r.get('name') or r.get('original_name') or '',
            'original_title': r.get('original_name') or '',
            'year': int(date[:4]) if date[:4].isdigit() else 0,
            'plot': r.get('overview') or '',
            'rating': float(r.get('vote_average') or 0),
            'votes': int(r.get('vote_count') or 0),
            'poster': IMG_URL + 'w500' + r['poster_path'] if r.get('poster_path') else '',
            'fanart': IMG_URL + 'w1280' + r['backdrop_path'] if r.get('backdrop_path') else '',
        }
