# -*- coding: utf-8 -*-
"""Minimální klient pro Webshare.cz API (https://webshare.cz/apidoc/)."""
import hashlib
from http.client import HTTPException
import xml.etree.ElementTree as ET
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from md5crypt import md5crypt

API_URL = 'https://webshare.cz/api/'
HEADERS = {
    'Accept': 'text/xml; charset=UTF-8',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'https://webshare.cz/',
}
TIMEOUT = 20


class WebshareError(Exception):
    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code


def _text(node, tag, default=''):
    el = node.find(tag)
    return el.text if el is not None and el.text is not None else default


class Webshare:
    def __init__(self, token=None, version='1.0'):
        self.token = token
        self.headers = dict(HEADERS)
        self.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi-Webshare-Search/' + version

    def _call(self, endpoint, data, auth=True):
        data = dict(data)
        if auth and self.token:
            data['wst'] = self.token
        req = Request(API_URL + endpoint + '/', data=urlencode(data).encode('utf-8'), headers=self.headers)
        try:
            with urlopen(req, timeout=TIMEOUT) as resp:
                body = resp.read()
        except (OSError, HTTPException) as e:  # URLError, timeout, přerušené spojení
            raise WebshareError('Nelze se spojit s Webshare.cz: %s' % getattr(e, 'reason', e), 'NETWORK')
        try:
            root = ET.fromstring(body)
        except ET.ParseError:
            raise WebshareError('Neplatná odpověď serveru Webshare.cz', 'BAD_RESPONSE')
        if _text(root, 'status') != 'OK':
            raise WebshareError(_text(root, 'message', 'Neznámá chyba'), _text(root, 'code') or None)
        return root

    # --- účet -------------------------------------------------------------

    def login(self, username, password):
        if not username or not password:
            raise WebshareError('Vyplňte v nastavení doplňku uživatelské jméno a heslo.', 'NO_CREDENTIALS')
        salt = _text(self._call('salt', {'username_or_email': username}, auth=False), 'salt')
        if not salt:
            raise WebshareError('Uživatel nenalezen.', 'NO_SALT')
        pass_hash = hashlib.sha1(md5crypt(password, salt).encode('utf-8')).hexdigest()
        digest = hashlib.md5((username + ':Webshare:' + password).encode('utf-8')).hexdigest()
        root = self._call('login', {
            'username_or_email': username,
            'password': pass_hash,
            'digest': digest,
            'keep_logged_in': 1,
        }, auth=False)
        self.token = _text(root, 'token')
        if not self.token:
            raise WebshareError('Přihlášení se nezdařilo.', 'NO_TOKEN')
        return self.token

    def user_data(self):
        root = self._call('user_data', {})
        return {
            'username': _text(root, 'username'),
            'email': _text(root, 'email'),
            'vip': _text(root, 'vip') == '1',
            'vip_days': _text(root, 'vip_days', '0'),
            'vip_until': _text(root, 'vip_until'),
        }

    # --- soubory ----------------------------------------------------------

    def search(self, what, category='video', sort='', limit=50, offset=0):
        root = self._call('search', {
            'what': what,
            'category': category,
            'sort': sort,
            'limit': limit,
            'offset': offset,
        })
        files = []
        for f in root.findall('file'):
            files.append({
                'ident': _text(f, 'ident'),
                'name': _text(f, 'name'),
                'type': _text(f, 'type'),
                'size': int(_text(f, 'size', '0') or 0),
                'img': _text(f, 'img'),
                'positive_votes': int(_text(f, 'positive_votes', '0') or 0),
                'negative_votes': int(_text(f, 'negative_votes', '0') or 0),
                'password': _text(f, 'password') == '1',
            })
        return files, int(_text(root, 'total', '0') or 0)

    def file_link(self, ident, download_type='video_stream'):
        """download_type: video_stream (přehrávání) nebo file_download (stažení)."""
        root = self._call('file_link', {'ident': ident, 'download_type': download_type})
        link = _text(root, 'link')
        if not link:
            raise WebshareError('Nepodařilo se získat odkaz na video.')
        return link
