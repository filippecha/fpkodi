# -*- coding: utf-8 -*-
"""Pure-Python MD5-crypt ($1$), compatible with `openssl passwd -1`.

Kodi neobsahuje passlib ani modul crypt, proto vlastní implementace.
"""
import hashlib

_ITOA64 = './0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
_MAGIC = '$1$'


def _to64(value, length):
    out = ''
    while length > 0:
        out += _ITOA64[value & 0x3f]
        value >>= 6
        length -= 1
    return out


def md5crypt(password, salt):
    if salt.startswith(_MAGIC):
        salt = salt[len(_MAGIC):]
    salt = salt.split('$', 1)[0][:8]

    pw = password.encode('utf-8')
    s = salt.encode('utf-8')

    alt = hashlib.md5(pw + s + pw).digest()
    ctx = pw + _MAGIC.encode('ascii') + s
    remaining = len(pw)
    while remaining > 0:
        ctx += alt[:min(16, remaining)]
        remaining -= 16

    i = len(pw)
    while i:
        ctx += b'\x00' if i & 1 else pw[:1]
        i >>= 1

    final = hashlib.md5(ctx).digest()

    for i in range(1000):
        c = pw if i & 1 else final
        if i % 3:
            c += s
        if i % 7:
            c += pw
        c += final if i & 1 else pw
        final = hashlib.md5(c).digest()

    f = final
    result = (
        _to64((f[0] << 16) | (f[6] << 8) | f[12], 4) +
        _to64((f[1] << 16) | (f[7] << 8) | f[13], 4) +
        _to64((f[2] << 16) | (f[8] << 8) | f[14], 4) +
        _to64((f[3] << 16) | (f[9] << 8) | f[15], 4) +
        _to64((f[4] << 16) | (f[10] << 8) | f[5], 4) +
        _to64(f[11], 2)
    )
    return _MAGIC + salt + '$' + result
