# -*- coding: utf-8 -*-
import json
import os
import re
import sys
import time
from difflib import SequenceMatcher
from http.client import HTTPException
from urllib.parse import parse_qsl, urlencode, urlparse
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
HISTORY_FILE = os.path.join(PROFILE, 'history.json')
RECENT_FILE = os.path.join(PROFILE, 'recent.json')
PAGE_FILE = os.path.join(PROFILE, 'last_page.json')
TMDB_CACHE = os.path.join(PROFILE, 'tmdb_cache.json')

LIB_DIR = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('path')), 'resources', 'lib')
if LIB_DIR not in sys.path:  # reuselanguageinvoker spouští skript opakovaně ve stejném interpretu
    sys.path.insert(0, LIB_DIR)
import quality  # noqa: E402
from tmdb import Tmdb, TmdbError  # noqa: E402
from webshare import Webshare, WebshareError  # noqa: E402

BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
PAGE_SIZE = 100  # víc výsledků na stránce = víc verzí stejného filmu v jedné skupině
RECENT_SIZE = 50
SORTS = ['', 'recent', 'rating', 'largest', 'smallest']
VIDEO_EXT = ('avi', 'mkv', 'mp4', 'm4v', 'mov', 'wmv', 'mpg', 'mpeg', 'ts', 'm2ts', 'flv', 'webm', 'divx', 'xvid', 'vob', '3gp')
GB = 1024 ** 3
DOWNLOAD_CHUNK = 1024 * 1024
HOME_WINDOW = 10000  # vlastnosti okna Home přežijí mezi spuštěními skriptu


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, ms)


def build_url(**params):
    return BASE_URL + '?' + urlencode(params)


def human_size(size):
    for unit in ('B', 'KB', 'MB', 'GB'):
        if size < 1024:
            return '%.0f %s' % (size, unit) if unit in ('B', 'KB') else '%.1f %s' % (size, unit)
        size /= 1024.0
    return '%.2f TB' % size


# --- přihlášení -----------------------------------------------------------

def get_client(force_login=False):
    """Vrátí přihlášeného klienta; token se ukládá do skrytého nastavení."""
    username = ADDON.getSetting('username').strip()
    password = ADDON.getSetting('password')
    token = ADDON.getSetting('token')
    # Změna účtu v nastavení => nové přihlášení
    if ADDON.getSetting('token_user') != username:
        token = ''
    client = Webshare(token or None, ADDON_VERSION)
    client.fresh_login = force_login or not token
    if client.fresh_login:
        client.login(username, password)
        ADDON.setSetting('token', client.token)
        ADDON.setSetting('token_user', username)
        log('Přihlášení na Webshare proběhlo úspěšně')
    return client


def token_valid(client):
    try:
        client.user_data()
        return True
    except WebshareError:
        return False


def call_api(fn):
    """Zavolá fn(client); když chyba plyne z neplatného tokenu, jednou se znovu přihlásí."""
    client = get_client()
    try:
        return fn(client)
    except WebshareError as e:
        if e.code in ('NO_CREDENTIALS', 'NETWORK') or client.fresh_login or token_valid(client):
            raise
        log('Chyba API (%s: %s), token je neplatný, přihlašuji se znovu' % (e.code, e), xbmc.LOGWARNING)
        return fn(get_client(force_login=True))


def handle_error(e):
    log('Chyba: %s' % e, xbmc.LOGERROR)
    if getattr(e, 'code', None) == 'NO_CREDENTIALS':
        if xbmcgui.Dialog().yesno(ADDON_NAME, 'Nejste přihlášeni.[CR]Chcete otevřít nastavení a zadat jméno a heslo k Webshare?'):
            ADDON.openSettings()
    else:
        xbmcgui.Dialog().ok(ADDON_NAME, str(e))


def is_free_link(link):
    return (urlparse(link).hostname or '').startswith('free.')


def get_link(ident, download_type='video_stream'):
    link = call_api(lambda c: c.file_link(ident, download_type))
    if is_free_link(link):
        # S vypršelým tokenem Webshare nevrátí chybu, ale pomalý odkaz pro neplatící
        log('Webshare vrátil odkaz bez VIP, přihlašuji se znovu', xbmc.LOGWARNING)
        link = get_client(force_login=True).file_link(ident, download_type)
        if is_free_link(link):
            notify('Účet nemá aktivní VIP, přenos bude pomalý.', xbmcgui.NOTIFICATION_WARNING, 6000)
    return link


# --- uložené seznamy (historie hledání, naposledy přehrané) ---------------

def load_list(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            items = json.load(f)
    except (IOError, OSError, ValueError):
        return []
    return items if isinstance(items, list) else []


def save_list(path, items):
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(items, f, ensure_ascii=False)


def load_history():
    return [q for q in load_list(HISTORY_FILE) if isinstance(q, str) and q.strip()]


def add_to_history(query):
    items = [q for q in load_history() if q.lower() != query.lower()]
    items.insert(0, query)
    save_list(HISTORY_FILE, items[:int(ADDON.getSetting('history_size') or 20)])


def load_recent():
    return [f for f in load_list(RECENT_FILE)
            if isinstance(f, dict) and f.get('ident') and isinstance(f.get('name'), str) and isinstance(f.get('size'), int)]


def add_to_recent(ident, name, size):
    items = [f for f in load_recent() if f['ident'] != ident]
    items.insert(0, {'ident': ident, 'name': name, 'size': size})
    save_list(RECENT_FILE, items[:RECENT_SIZE])


# --- obrazovky ------------------------------------------------------------

def add_dir(label, url, icon='DefaultFolder.png', context=None, bottom=False):
    li = xbmcgui.ListItem(label)
    li.setArt({'icon': icon, 'thumb': icon})
    if context:
        li.addContextMenuItems(context)
    if bottom:
        li.setProperty('SpecialSort', 'bottom')  # zůstane dole při jakémkoli řazení
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def set_video_info(li, title, mediatype, movie=None, size=0):
    """Nastaví informace o videu; Kodi 20+ přes InfoTagVideo, Kodi 19 přes setInfo."""
    if size:
        # Velikost pro řazení a zobrazení; InfoTagVideo (Kodi 20+) ji nastavit neumí
        li.setInfo('video', {'size': size})
    try:
        tag = li.getVideoInfoTag()  # Kodi 20+
        tag.setTitle(title)
        tag.setMediaType(mediatype)
        if movie:
            tag.setOriginalTitle(movie.get('original_title', ''))
            tag.setPlot(movie.get('plot', ''))
            tag.setYear(movie.get('year', 0))
            tag.setRating(movie.get('rating', 0), movie.get('votes', 0), 'themoviedb', True)
            if 'episode' in movie:
                tag.setTvShowTitle(movie['tvshowtitle'])
                tag.setSeason(movie['season'])
                tag.setEpisode(movie['episode'])
                tag.setFirstAired(movie.get('aired', ''))
            elif 'season' in movie:
                tag.setTvShowTitle(movie['tvshowtitle'])
                tag.setSeason(movie['season'])
    except AttributeError:
        info = {'title': title, 'mediatype': mediatype}
        if movie:
            info.update({'originaltitle': movie.get('original_title', ''), 'plot': movie.get('plot', ''),
                         'year': movie.get('year', 0), 'rating': movie.get('rating', 0),
                         'votes': str(movie.get('votes', 0))})
            for k in ('tvshowtitle', 'season', 'episode', 'aired'):
                if k in movie:
                    info[k] = movie[k]
        li.setInfo('video', info)


def movie_art(movie, fallback_img=''):
    if movie and movie.get('still'):  # díl seriálu: záběr z dílu, pozadí ze seriálu
        return {'thumb': movie['still'], 'poster': movie.get('poster') or movie['still'],
                'fanart': movie.get('fanart') or movie['still']}
    if movie and movie['poster']:
        return {'thumb': movie['poster'], 'poster': movie['poster'], 'fanart': movie['fanart'] or movie['poster']}
    if fallback_img:
        return {'thumb': fallback_img, 'poster': fallback_img, 'fanart': fallback_img}
    return {'icon': 'DefaultVideo.png'}


def add_file(f, context=(), movie=None):
    """Přidá přehratelnou položku. URL musí být pro stejný soubor vždy stejná, jinak Kodi nenajde rozkoukané místo."""
    label = f['name']
    if ADDON.getSetting('show_tags') != 'false':
        tags = quality.parse(f['name'])['tags']
        if tags:
            label += '  [COLOR deepskyblue]%s[/COLOR]' % ' · '.join(tags)
    label += '  [COLOR gray][%s][/COLOR]' % human_size(f['size'])
    if f.get('positive_votes') or f.get('negative_votes'):
        label += '  [COLOR green]+%d[/COLOR][COLOR red]-%d[/COLOR]' % (f['positive_votes'], f['negative_votes'])
    li = xbmcgui.ListItem(label)
    li.setLabel2(human_size(f['size']))
    li.setArt(movie_art(movie, f.get('img')))
    set_video_info(li, f['name'], 'video', movie, f['size'])
    li.setProperty('IsPlayable', 'true')
    li.addContextMenuItems([
        ('Stáhnout', 'RunPlugin(%s)' % build_url(action='download', ident=f['ident'], name=f['name'])),
    ] + list(context))
    url = build_url(action='play', ident=f['ident'], name=f['name'], size=f['size'])
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


def file_allowed(f, only_video, max_size, min_quality):
    if f['password']:
        return False  # soubory chráněné heslem nelze přehrát
    if only_video and f['type'].lower() not in VIDEO_EXT:
        return False
    if max_size and f['size'] > max_size:
        return False
    if min_quality:
        height = quality.parse(f['name'])['height']
        if min_quality == 1 and height < 720:
            return False
        if min_quality == 2 and height < 1080:
            return False
        if min_quality == 3 and height > 1080:
            return False
    return True


def main_menu():
    add_dir('[B]Hledat[/B]', build_url(action='new_search'), 'DefaultAddonsSearch.png')
    if get_tmdb():
        add_dir('Filmy', build_url(action='movies_menu'), 'DefaultMovies.png')
        add_dir('Seriály', build_url(action='tv_menu'), 'DefaultTVShows.png')
    if load_recent():
        add_dir('Naposledy přehrané', build_url(action='recent'), 'DefaultRecentlyAddedMovies.png')
    for q in load_history():
        add_dir(q, build_url(action='search', query=q, offset=0), 'DefaultAddonsSearch.png', context=[
            ('Odebrat z historie', 'RunPlugin(%s)' % build_url(action='history_remove', query=q)),
            ('Vymazat celou historii', 'RunPlugin(%s)' % build_url(action='history_clear')),
        ])
    add_dir('Můj účet', build_url(action='account'), 'DefaultUser.png')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def new_search():
    query = xbmcgui.Dialog().input('Hledat na Webshare', type=xbmcgui.INPUT_ALPHANUM).strip()
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    if query:
        add_to_history(query)
        # Přesměrování, aby se při návratu zpět znovu neotevírala klávesnice
        xbmc.executebuiltin('Container.Update(%s)' % build_url(action='search', query=query, offset=0))


def set_video_listing(category):
    xbmcplugin.setPluginCategory(HANDLE, category)
    xbmcplugin.setContent(HANDLE, 'videos')
    for method in (xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL, xbmcplugin.SORT_METHOD_SIZE):
        xbmcplugin.addSortMethod(HANDLE, method)


def czech_plural(n, one, few, many):
    return one if n == 1 else few if 2 <= n <= 4 else many


def lookup_movies(files):
    """Vrátí {ident: film z TMDB} pro soubory, které se podařilo dohledat. Bez klíče prázdný slovník."""
    key = ADDON.getSetting('tmdb_key').strip()
    if not key or not files:
        return {}
    # Díly seriálů (S01E05) se s filmy nepárují, 'Přátelé S01E05' by se našlo jako film 'Přátelé'
    names = {f['ident']: quality.title_year(f['name']) for f in files if not quality.episode_code(f['name'])}
    try:
        found = Tmdb(key, TMDB_CACHE).lookup_many([ty for ty in names.values() if ty[0]])
    except TmdbError as e:
        log(str(e), xbmc.LOGWARNING)
        notify(str(e), xbmcgui.NOTIFICATION_WARNING, 6000)
        return {}
    return {ident: found[ty] for ident, ty in names.items() if found.get(ty)}


def group_files(files, movies):
    """Seskupí verze stejného filmu: podle ID v TMDB, jinak podle názvu a roku z názvu souboru.

    Vrátí seznam (klíč, popisek, film nebo None, [soubory]) v pořadí prvního výskytu.
    Soubory bez roku a bez shody v TMDB zůstanou samostatně (riziko sloučení různých filmů).
    """
    grouping = ADDON.getSetting('group_results') != 'false'
    groups = {}
    for f in files:
        movie = movies.get(f['ident'])
        title, year = quality.title_year(f['name'])
        if grouping and movie:
            key = 'tmdb:%d' % movie['id']
            label = '%s (%d)' % (movie['title'], movie['year']) if movie['year'] else movie['title']
        elif grouping and title and year and not quality.episode_code(f['name']):
            key, label = 'text:' + quality.group_key(title, year), '%s (%d)' % (title, year)
        else:
            key, label = 'file:' + f['ident'], f['name']
        groups.setdefault(key, (key, label, movie, []))[3].append(f)
    return list(groups.values())


def load_page(query, offset, cached=False):
    """Stránka výsledků po filtrech. cached=True použije uloženou stránku (otevření skupiny bez nového dotazu)."""
    sort = SORTS[int(ADDON.getSetting('sort') or 0)]
    only_video = ADDON.getSetting('only_video_ext') != 'false'
    max_size = int(ADDON.getSetting('max_size') or 0) * GB
    min_quality = int(ADDON.getSetting('min_quality') or 0)
    page_id = [query, offset, sort, only_video, max_size, min_quality]
    if cached:
        for page in load_list(PAGE_FILE):
            if isinstance(page, dict) and page.get('id') == page_id:
                return page['files'], page['total'], page['found']
    files, total = call_api(lambda c: c.search(query, 'video', sort, PAGE_SIZE, offset))
    allowed = [f for f in files if file_allowed(f, only_video, max_size, min_quality)]
    pages = [p for p in load_list(PAGE_FILE) if isinstance(p, dict) and p.get('id') != page_id]
    save_list(PAGE_FILE, [{'id': page_id, 'files': allowed, 'total': total, 'found': len(files)}] + pages[:4])
    return allowed, total, len(files)


def search(query, offset):
    try:
        files, total, found = load_page(query, offset)
    except WebshareError as e:
        handle_error(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    set_video_listing(query)
    for key, label, movie, group_list in group_files(files, lookup_movies(files)):
        if len(group_list) == 1:
            add_file(group_list[0], movie=movie)
            continue
        heights = sorted({quality.parse(f['name'])['height'] for f in group_list} - {0}, reverse=True)
        res = ' · '.join('4K' if h == 2160 else 'SD' if h == 480 else '%dp' % h for h in heights)
        text = '[B]%s[/B]' % label
        if res:
            text += '  [COLOR deepskyblue]%s[/COLOR]' % res
        text += '  [COLOR gray]%d %s[/COLOR]' % (len(group_list), czech_plural(len(group_list), 'verze', 'verze', 'verzí'))
        li = xbmcgui.ListItem(text)
        li.setArt(movie_art(movie) if movie else {'icon': 'DefaultMovies.png', 'thumb': 'DefaultMovies.png'})
        set_video_info(li, movie['title'] if movie else label, 'movie' if movie else 'video', movie)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action='group', query=query, offset=offset, key=key), li, isFolder=True)

    if offset + PAGE_SIZE < total:
        page = offset // PAGE_SIZE + 2
        pages = (total + PAGE_SIZE - 1) // PAGE_SIZE
        add_dir('[B]Další strana (%d/%d) >>[/B]' % (page, pages),
                build_url(action='search', query=query, offset=offset + PAGE_SIZE), 'DefaultFolder.png', bottom=True)

    if not files and offset == 0:
        if found:
            notify('Nic k přehrání: %s (výsledky skryl filtr)' % query)
        else:
            notify('Nic nenalezeno: %s' % query)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def group(query, offset, key):
    """Verze jednoho filmu ze stránky výsledků."""
    try:
        files, _, _ = load_page(query, offset, cached=True)
    except WebshareError as e:
        handle_error(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    for k, label, movie, group_list in group_files(files, lookup_movies(files)):
        if k == key:
            set_video_listing(label)
            for f in group_list:
                add_file(f, movie=movie)
            break
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# --- procházení (TMDB) ------------------------------------------------------

MOVIE_MENU = [
    ('trending', 'Trendy dnes'),
    ('popular', 'Populární'),
    ('now_playing', 'V kinech'),
    ('digital', 'Nově na VOD a Blu-ray'),
    ('top_rated', 'Nejlépe hodnocené'),
]
TV_MENU = [
    ('trending', 'Trendy dnes'),
    ('popular', 'Populární'),
    ('on_the_air', 'Právě vysílané'),
    ('top_rated', 'Nejlépe hodnocené'),
]


def get_tmdb():
    key = ADDON.getSetting('tmdb_key').strip()
    return Tmdb(key, TMDB_CACHE) if key else None


def tmdb_call(fn):
    """Zavolá fn(tmdb); při chybě ukáže hlášku a vrátí None."""
    tm = get_tmdb()
    if not tm:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Pro procházení filmů a seriálů zadejte v nastavení TMDB API klíč.')
        return None
    try:
        return fn(tm)
    except TmdbError as e:
        xbmcgui.Dialog().ok(ADDON_NAME, str(e))
    except (OSError, HTTPException, ValueError, KeyError) as e:
        log('TMDB: %s' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'Databáze filmů TMDB není dostupná:[CR]%s' % getattr(e, 'reason', e))
    return None


def rating_label(item):
    return '  [COLOR gold]★ %.1f[/COLOR]' % item['rating'] if item.get('votes') else ''


def add_title_dir(item, url, mediatype, label=None):
    """Složka filmu, seriálu nebo sezóny s plakátem a popisem."""
    text = label or '[B]%s[/B]%s%s' % (item['title'], ' (%d)' % item['year'] if item.get('year') else '', rating_label(item))
    li = xbmcgui.ListItem(text)
    li.setArt(movie_art(item) if item.get('poster') or item.get('still') else {'icon': 'DefaultVideo.png'})
    set_video_info(li, item['title'], mediatype, item)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def end_listing(content, category):
    xbmcplugin.setPluginCategory(HANDLE, category)
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE)


def movies_menu():
    for kind, label in MOVIE_MENU:
        add_dir(label, build_url(action='movie_list', kind=kind, page=1), 'DefaultMovies.png')
    end_listing('files', 'Filmy')


def tv_menu():
    add_dir('[B]Hledat seriál[/B]', build_url(action='tv_search'), 'DefaultAddonsSearch.png')
    for kind, label in TV_MENU:
        add_dir(label, build_url(action='tv_list', kind=kind, page=1), 'DefaultTVShows.png')
    end_listing('files', 'Seriály')


def next_page(action, kind, page, pages):
    if page < pages:
        add_dir('[B]Další strana (%d/%d) >>[/B]' % (page + 1, pages),
                build_url(action=action, kind=kind, page=page + 1), 'DefaultFolder.png', bottom=True)


def movie_list(kind, page):
    result = tmdb_call(lambda tm: tm.movie_list(kind, page))
    if result is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    movies, pages = result
    for m in movies:
        add_title_dir(m, build_url(action='movie', id=m['id']), 'movie')
    next_page('movie_list', kind, page, pages)
    end_listing('movies', dict(MOVIE_MENU).get(kind, 'Filmy'))


def search_webshare(queries):
    """Spojí výsledky více hledání na Webshare (bez duplicit) a použije filtry z nastavení."""
    only_video = ADDON.getSetting('only_video_ext') != 'false'
    max_size = int(ADDON.getSetting('max_size') or 0) * GB
    min_quality = int(ADDON.getSetting('min_quality') or 0)
    files = {}
    for q in dict.fromkeys(q for q in queries if q):
        found, _ = call_api(lambda c: c.search(q, 'video', '', PAGE_SIZE, 0))
        for f in found:
            if f['ident'] not in files and file_allowed(f, only_video, max_size, min_quality):
                files[f['ident']] = f
    return list(files.values())


def matches_title(name, titles, year):
    """Patří soubor k filmu? S rokem stačí podobný název (rok ±1), bez roku jen přesná shoda názvu."""
    if quality.episode_code(name):
        return False
    title, file_year = quality.title_year(name)
    variants = {quality.normalize(v) for v in [title] + title.split(' - ')} - {''}
    wanted = {quality.normalize(t) for t in titles} - {''}
    if file_year:
        if not year or abs(file_year - year) > 1:
            return False
        return any(SequenceMatcher(None, v, w).ratio() >= 0.7 for v in variants for w in wanted)
    return bool(variants & wanted)


def add_manual_search(title):
    add_dir('[COLOR gray]Hledat na Webshare: %s[/COLOR]' % title,
            build_url(action='search', query=title, offset=0), 'DefaultAddonsSearch.png', bottom=True)


def movie(movie_id):
    """Verze filmu z katalogu na Webshare: hledá se český i původní název, párování přes TMDB."""
    m = tmdb_call(lambda tm: tm.movie(movie_id))
    if m is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    titles = [m['title'], m['original_title'], m['english_title']]
    try:
        files = search_webshare(titles)
    except WebshareError as e:
        handle_error(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    candidates = [f for f in files if matches_title(f['name'], titles, m['year'])]
    # Pojistka: soubor, který TMDB přiřadí k jinému filmu ('Making The Matrix 1999'), se vyřadí
    movies = lookup_movies(candidates)
    matched = [f for f in candidates if movies.get(f['ident'], {}).get('id', m['id']) == m['id']]

    set_video_listing(m['title'])
    for f in matched:
        add_file(f, movie=m)
    if not matched:
        notify('Na Webshare nenalezeno: %s' % m['title'])
    add_manual_search(m['title'])
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# --- seriály ----------------------------------------------------------------

def tv_list(kind, page):
    result = tmdb_call(lambda tm: tm.tv_list(kind, page))
    if result is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    shows, pages = result
    for sh in shows:
        add_title_dir(sh, build_url(action='tv', id=sh['id']), 'tvshow')
    next_page('tv_list', kind, page, pages)
    end_listing('tvshows', dict(TV_MENU).get(kind, 'Seriály'))


def tv_search():
    query = xbmcgui.Dialog().input('Hledat seriál', type=xbmcgui.INPUT_ALPHANUM).strip()
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    if query:
        xbmc.executebuiltin('Container.Update(%s)' % build_url(action='tv_results', query=query))


def tv_results(query):
    shows = tmdb_call(lambda tm: tm.search_tv(query))
    if shows is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    for sh in shows:
        add_title_dir(sh, build_url(action='tv', id=sh['id']), 'tvshow')
    if not shows:
        notify('Seriál nenalezen: %s' % query)
    end_listing('tvshows', query)


def tv(tv_id):
    show = tmdb_call(lambda tm: tm.tv(tv_id))
    if show is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    # Speciály (sezóna 0) na konec, na Webshare bývají zřídka
    for se in sorted(show['seasons'], key=lambda x: (x['number'] == 0, x['number'])):
        info = dict(se, title=se['name'], tvshowtitle=show['title'], season=se['number'],
                    fanart=show['fanart'], rating=0, votes=0)
        label = '[B]%s[/B]  [COLOR gray]%d %s%s[/COLOR]' % (
            se['name'], se['episodes'], czech_plural(se['episodes'], 'díl', 'díly', 'dílů'),
            ', %d' % se['year'] if se['year'] else '')
        add_title_dir(info, build_url(action='season', id=tv_id, season=se['number']), 'season', label)
    end_listing('seasons', show['title'])


def season(tv_id, number):
    data = tmdb_call(lambda tm: (tm.tv(tv_id), tm.season(tv_id, number)))
    if data is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    show, episodes = data
    today = time.strftime('%Y-%m-%d')
    for ep in episodes:
        if not ep['aired'] or ep['aired'] > today:
            continue  # ještě neodvysílané díly na Webshare nebudou
        info = dict(ep, title=ep['name'], tvshowtitle=show['title'], poster=show['poster'], fanart=show['fanart'],
                    original_title='', year=int(ep['aired'][:4]))
        label = '%dx%02d  [B]%s[/B]%s' % (ep['season'], ep['episode'], ep['name'], rating_label(ep))
        add_title_dir(info, build_url(action='episode', id=tv_id, season=ep['season'], episode=ep['episode']),
                      'episode', label)
    end_listing('episodes', '%s – %d. sezóna' % (show['title'], number))


def episode(tv_id, season_no, episode_no):
    """Soubory jednoho dílu na Webshare: hledá 'Název S01E05' česky i původním názvem."""
    data = tmdb_call(lambda tm: (tm.tv(tv_id), tm.season(tv_id, season_no)))
    if data is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    show, episodes = data
    ep = next((e for e in episodes if e['episode'] == episode_no), {'name': '', 'plot': '', 'still': '',
                                                                      'aired': '', 'rating': 0, 'votes': 0})
    code = 'S%02dE%02d' % (season_no, episode_no)
    try:
        files = search_webshare(['%s %s' % (t, code) for t in (show['title'], show['original_title'], show['english_title']) if t])
    except WebshareError as e:
        handle_error(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    names = {quality.normalize(t) for t in (show['title'], show['original_title'], show['english_title'])} - {''}
    names |= {n[4:] for n in names if n.startswith('the ')}  # 'The Big Bang Theory' i 'Big Bang Theory'
    matched = [f for f in files if quality.episode_code(f['name']) == (season_no, episode_no)
               and any(n in quality.normalize(f['name']) for n in names)]

    info = dict(ep, title=ep['name'], tvshowtitle=show['title'], season=season_no, episode=episode_no,
                poster=show['poster'], fanart=show['fanart'], original_title='',
                year=int(ep['aired'][:4]) if ep['aired'][:4].isdigit() else 0)
    set_video_listing('%s %dx%02d %s' % (show['title'], season_no, episode_no, ep['name']))
    for f in matched:
        add_file(f, movie=info)
    if not matched:
        notify('Na Webshare nenalezeno: %s %s' % (show['title'], code))
    add_manual_search('%s %s' % (show['title'], code))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def recent():
    set_video_listing('Naposledy přehrané')
    items = load_recent()
    movies = lookup_movies(items)
    for f in items:
        add_file(f, movie=movies.get(f['ident']), context=[
            ('Odebrat z naposledy přehraných', 'RunPlugin(%s)' % build_url(action='recent_remove', ident=f['ident'])),
            ('Vymazat naposledy přehrané', 'RunPlugin(%s)' % build_url(action='recent_clear')),
        ])
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def play(ident, name, size):
    try:
        link = get_link(ident)
    except WebshareError as e:
        handle_error(e)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    log('Přehrávám %s' % name)
    add_to_recent(ident, name, size)
    li = xbmcgui.ListItem(name, path=link)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# --- stahování ------------------------------------------------------------

def target_path(folder, name):
    """Cesta k novému souboru ve složce (i síťové smb://…); při kolizi přidá (1), (2)…"""
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', '_', name).strip(' .') or 'video'
    base, ext = os.path.splitext(name)
    sep = '/' if '://' in folder or '/' in folder else os.sep
    folder = folder.rstrip('/\\') + sep
    path, n = folder + name, 1
    while xbmcvfs.exists(path) or xbmcvfs.exists(path + '.part'):
        path, n = '%s%s (%d)%s' % (folder, base, n, ext), n + 1
    return path


def download(ident, name):
    win = xbmcgui.Window(HOME_WINDOW)
    prop = '%s.download.%s' % (ADDON_ID, ident)
    if win.getProperty(prop):
        if xbmcgui.Dialog().yesno(ADDON_NAME, 'Soubor se právě stahuje:[CR]%s[CR][CR]Zrušit stahování?' % name):
            win.setProperty(prop, 'cancel')
        return

    folder = ADDON.getSetting('download_dir')
    if not folder:
        folder = xbmcgui.Dialog().browse(3, 'Složka pro stahování', 'files')
        if not folder:
            return
        ADDON.setSetting('download_dir', folder)
    try:
        link = get_link(ident, 'file_download')
    except WebshareError as e:
        handle_error(e)
        return

    path = target_path(folder, name)
    part = path + '.part'
    win.setProperty(prop, 'running')
    progress = xbmcgui.DialogProgressBG()
    progress.create(ADDON_NAME, 'Stahuji: %s' % name)
    monitor = xbmc.Monitor()
    done = total = 0
    result = 'error'
    error = ''
    log('Stahuji %s -> %s' % (name, path))
    try:
        req = Request(link, headers={'User-Agent': 'Kodi-Webshare-Search/' + ADDON_VERSION})
        with urlopen(req, timeout=30) as resp:
            total = int(resp.headers.get('Content-Length') or 0)
            out = xbmcvfs.File(part, 'w')
            try:
                start = last_update = time.time()
                while True:
                    if monitor.abortRequested() or win.getProperty(prop) == 'cancel':
                        result = 'cancel'
                        break
                    chunk = resp.read(DOWNLOAD_CHUNK)
                    if not chunk:
                        result = 'ok' if not total or done == total else 'error'
                        error = '' if result == 'ok' else 'Spojení se přerušilo.'
                        break
                    if not out.write(bytearray(chunk)):
                        error = 'Nelze zapisovat do %s' % folder
                        break
                    done += len(chunk)
                    now = time.time()
                    if now - last_update >= 1:
                        last_update = now
                        speed = done / max(now - start, 0.001)
                        progress.update(done * 100 // total if total else 0, message='%s – %s / %s (%s/s)' % (
                            name, human_size(done), human_size(total), human_size(speed)))
            finally:
                out.close()
    except (OSError, HTTPException) as e:
        error = 'Chyba: %s' % getattr(e, 'reason', e)
    finally:
        progress.close()
        win.clearProperty(prop)

    if result == 'ok' and xbmcvfs.rename(part, path):
        log('Staženo: %s (%s)' % (path, human_size(done)))
        notify('Staženo: %s' % name, ms=6000)
        return
    xbmcvfs.delete(part)
    if result == 'cancel':
        notify('Stahování zrušeno: %s' % name)
    else:
        log('Stahování selhalo: %s: %s' % (name, error or 'nelze přejmenovat .part'), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'Stahování selhalo:[CR]%s[CR]%s' % (name, error or 'Soubor nelze uložit.'))


# --- účet -----------------------------------------------------------------

def account():
    try:
        data = call_api(lambda c: c.user_data())
    except WebshareError as e:
        handle_error(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if data['vip']:
        vip = '[COLOR green]VIP aktivní[/COLOR] – zbývá %s dní (do %s)' % (data['vip_days'], data['vip_until'])
    else:
        vip = '[COLOR red]Bez VIP[/COLOR] – přehrávání bude pomalé/omezené'
    xbmcgui.Dialog().ok(ADDON_NAME, 'Účet: %s[CR]%s' % (data['username'], vip))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def test_login():
    """Voláno tlačítkem v nastavení."""
    ADDON.setSetting('token', '')
    try:
        client = get_client(force_login=True)
        data = client.user_data()
    except WebshareError as e:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Přihlášení selhalo:[CR]%s' % e)
        return
    if data['vip']:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Přihlášení OK (%s).[CR][COLOR green]VIP aktivní, zbývá %s dní.[/COLOR]' % (data['username'], data['vip_days']))
    else:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Přihlášení OK (%s).[CR][COLOR red]Účet nemá aktivní VIP.[/COLOR]' % data['username'])


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action = params.get('action')
    if action is None:
        main_menu()
    elif action == 'new_search':
        new_search()
    elif action == 'search':
        search(params['query'], int(params.get('offset', 0)))
    elif action == 'group':
        group(params['query'], int(params.get('offset', 0)), params.get('key', ''))
    elif action == 'recent':
        recent()
    elif action == 'movies_menu':
        movies_menu()
    elif action == 'tv_menu':
        tv_menu()
    elif action == 'movie_list':
        movie_list(params['kind'], int(params.get('page', 1)))
    elif action == 'movie':
        movie(int(params['id']))
    elif action == 'tv_list':
        tv_list(params['kind'], int(params.get('page', 1)))
    elif action == 'tv_search':
        tv_search()
    elif action == 'tv_results':
        tv_results(params['query'])
    elif action == 'tv':
        tv(int(params['id']))
    elif action == 'season':
        season(int(params['id']), int(params['season']))
    elif action == 'episode':
        episode(int(params['id']), int(params['season']), int(params['episode']))
    elif action == 'play':
        play(params['ident'], params.get('name', ''), int(params.get('size') or 0))
    elif action == 'download':
        download(params['ident'], params.get('name', ''))
    elif action == 'account':
        account()
    elif action == 'test_login':
        test_login()
    elif action == 'history_remove':
        save_list(HISTORY_FILE, [q for q in load_history() if q != params.get('query')])
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'history_clear':
        save_list(HISTORY_FILE, [])
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'recent_remove':
        save_list(RECENT_FILE, [f for f in load_recent() if f['ident'] != params.get('ident')])
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'recent_clear':
        save_list(RECENT_FILE, [])
        xbmc.executebuiltin('Container.Refresh')
    else:
        log('Neznámá akce: %s' % action, xbmc.LOGWARNING)


if __name__ == '__main__':
    router(sys.argv[2][1:] if len(sys.argv) > 2 else '')
